package org.hl7.fhir.utilities.xhtml;

public interface genImage {

}